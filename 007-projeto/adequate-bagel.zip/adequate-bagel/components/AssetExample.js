import * as React from 'react';
import { Text, View, StyleSheet, Image } from 'react-native';

export default function AssetExample() {
  return (
    <View style={styles.container}>
      <Text style={styles.paragraph}>
        Isso é uma das maravilhas do Mundo!
      </Text>
      <Text style={styles.paragraph}> 
        CUZCO-PERÚ
      </Text>
      <Image style={styles.logo} source={require('../assets/cuzco.png')} />
      <Image style={styles.logo} source={require('../assets/cuzco.png')} />
      <Image style={styles.logo} source={require('../assets/cuzco.png')} />
      <Image style={styles.logo} source={require('../assets/snack-icon.png')} />
    </View>
  );
}


const styles = StyleSheet.create({
  container: {
    alignItems: 'center',
    justifyContent: 'center',
    padding: 4,
    
  },
  paragraph: {
    margin: 24,
    marginTop: 0,
    fontSize: 24,
    fontWeight: 'italic',
    textAlign: 'center',
  },
  logo: {
    height: 228,
    width: 228,
  }
});
